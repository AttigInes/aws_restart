print("Python has three numeric types: int, float, and complex")
MyValue =1
print(MyValue)
print(type(MyValue))
print(str(MyValue) + " is of the data type " + str(type(MyValue)))

myValue =3.14
print(myValue)
print(type(myValue))
print(str(myValue) + " is the data type " + str(type(myValue)))

myvalue =5j
print(myvalue)
print(type(myvalue))
print(str(myvalue) + " is the data type " + str(type(myvalue)))

MyValue2 =True
print(MyValue2)
print(type(MyValue2))
print(str(MyValue2)+ " is the data type " + str(type(MyValue2)))